import 'package:flutter/material.dart';
import 'core/strings.dart';
import 'core/theme.dart';
import 'data/app_database.dart';
import 'data/repository.dart';
import 'ui/app_shell.dart';
import 'ui/welcome_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final repo = Repository(AppDatabase.instance);
  final owner = (await repo.setting('owner_name')) ?? 'Md Parvej Musharap';
  final anim = (await repo.setting('welcome_animation')) != '0';
  runApp(PsaApp(repo: repo, ownerName: owner, showWelcome: anim));
}

class PsaApp extends StatefulWidget {
  const PsaApp({super.key, required this.repo, required this.ownerName, required this.showWelcome});
  final Repository repo;
  final String ownerName;
  final bool showWelcome;
  @override
  State<PsaApp> createState() => _PsaAppState();
}

class _PsaAppState extends State<PsaApp> {
  late bool _welcome = widget.showWelcome;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: S.appName,
      debugShowCheckedModeBanner: false,
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: ThemeMode.system,
      home: _welcome
          ? WelcomeScreen(ownerName: widget.ownerName, onDone: () => setState(() => _welcome = false))
          : AppShell(repo: widget.repo, ownerName: widget.ownerName),
    );
  }
}
