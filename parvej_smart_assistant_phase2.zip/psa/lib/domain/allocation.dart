/// Pure payment-allocation logic (no database) so it can be unit tested.
class DueInvoice {
  final int purchaseId;
  final String purchaseDate; // YYYY-MM-DD
  final int remaining; // poisha
  const DueInvoice(this.purchaseId, this.purchaseDate, this.remaining);
}

class Allocation {
  final int purchaseId;
  final int amount;
  const Allocation(this.purchaseId, this.amount);
  @override
  bool operator ==(Object o) =>
      o is Allocation && o.purchaseId == purchaseId && o.amount == amount;
  @override
  int get hashCode => Object.hash(purchaseId, amount);
  @override
  String toString() => 'Allocation($purchaseId, $amount)';
}

class AllocationPreview {
  final List<Allocation> allocations;
  final int excess; // poisha not allocated to any invoice (candidate advance)
  const AllocationPreview(this.allocations, this.excess);
  int get allocated => allocations.fold(0, (s, a) => s + a.amount);
}

class AllocationError implements Exception {
  final String message;
  AllocationError(this.message);
  @override
  String toString() => message;
}

class AllocationLogic {
  /// Option C: settle the oldest outstanding invoices first.
  static AllocationPreview oldestFirst(List<DueInvoice> invoices, int amount) {
    if (amount <= 0) throw AllocationError('Payment must be greater than zero');
    final sorted = [...invoices]..sort((a, b) {
        final c = a.purchaseDate.compareTo(b.purchaseDate);
        return c != 0 ? c : a.purchaseId.compareTo(b.purchaseId);
      });
    var left = amount;
    final out = <Allocation>[];
    for (final inv in sorted) {
      if (left == 0) break;
      if (inv.remaining <= 0) continue;
      final pay = left < inv.remaining ? left : inv.remaining;
      out.add(Allocation(inv.purchaseId, pay));
      left -= pay;
    }
    return AllocationPreview(out, left);
  }

  /// Options A/B: the user picked the split. Never exceeds an invoice balance.
  static AllocationPreview manual(
      List<DueInvoice> invoices, Map<int, int> requested, int amount) {
    if (amount <= 0) throw AllocationError('Payment must be greater than zero');
    final byId = {for (final i in invoices) i.purchaseId: i};
    final out = <Allocation>[];
    var total = 0;
    requested.forEach((id, amt) {
      if (amt <= 0) return;
      final inv = byId[id];
      if (inv == null) throw AllocationError('Invoice $id is not outstanding');
      if (amt > inv.remaining) {
        throw AllocationError('Amount exceeds remaining due of invoice $id');
      }
      out.add(Allocation(id, amt));
      total += amt;
    });
    if (total > amount) {
      throw AllocationError('Allocated amount is more than the payment');
    }
    return AllocationPreview(out, amount - total);
  }
}
