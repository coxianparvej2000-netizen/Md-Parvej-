/// Bengali-first labels. Phase 2 covers shell + dashboard; more keys are added per phase.
class S {
  static const appName = 'PARVEJ SMART ASSISTANT';
  static const subtitle = 'আপনার ব্যক্তিগত ক্রয় ও আর্থিক সহকারী';
  static const goodMorning = 'শুভ সকাল';
  static const goodAfternoon = 'শুভ অপরাহ্ন';
  static const goodEvening = 'শুভ সন্ধ্যা';
  static const todayPurchase = 'আজকের ক্রয়';
  static const todaySupplierPayment = 'আজকের সরবরাহকারী পেমেন্ট';
  static const todayNewDue = 'আজকের নতুন বকেয়া';
  static const previousDuePayment = 'পুরোনো বকেয়া পরিশোধ';
  static const totalOutstanding = 'মোট সরবরাহকারী বকেয়া';
  static const restaurantReceived = 'রেস্টুরেন্ট থেকে প্রাপ্ত';
  static const restaurantOutstanding = 'রেস্টুরেন্টের কাছে পাওনা';
  static const availableCash = 'হাতে নগদ';
  static const home = 'হোম';
  static const purchases = 'ক্রয়';
  static const suppliers = 'সরবরাহকারী';
  static const dues = 'বকেয়া';
  static const more = 'আরও';
  static const newPurchase = 'নতুন ক্রয়';
  static const outstandingHistory = 'বকেয়ার বিস্তারিত হিসাব';
  static const skip = 'এড়িয়ে যান';
}
