/// All money is stored as integer poisha (1 Taka = 100 poisha).
/// All quantities are stored as integer thousandths (2.5 kg = 2500).
class Money {
  static const _bn = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

  static String _normalizeDigits(String s) {
    final b = StringBuffer();
    for (final r in s.runes) {
      final ch = String.fromCharCode(r);
      final i = _bn.indexOf(ch);
      b.write(i >= 0 ? '$i' : ch);
    }
    return b.toString().replaceAll(',', '').trim();
  }

  /// "1500.50" or "১৫০০.৫০" -> 150050. Throws FormatException on bad input.
  static int parseTaka(String input) => _parseScaled(input, 2);

  /// "2.5" -> 2500
  static int parseQtyMilli(String input) => _parseScaled(input, 3);

  static int _parseScaled(String input, int decimals) {
    final s = _normalizeDigits(input);
    if (s.isEmpty) return 0;
    if (!RegExp(r'^\d+(\.\d*)?$').hasMatch(s)) {
      throw FormatException('Invalid number: $input');
    }
    final parts = s.split('.');
    final whole = int.parse(parts[0]);
    var frac = parts.length > 1 ? parts[1] : '';
    if (frac.length > decimals) frac = frac.substring(0, decimals);
    frac = frac.padRight(decimals, '0');
    var scale = 1;
    for (var i = 0; i < decimals; i++) {
      scale *= 10;
    }
    return whole * scale + (frac.isEmpty ? 0 : int.parse(frac));
  }

  /// Line total in poisha = round_half_up(qtyMilli * unitPricePoisha / 1000).
  static int lineTotal(int qtyMilli, int unitPricePoisha) {
    return (qtyMilli * unitPricePoisha + 500) ~/ 1000;
  }

  static String toBengaliDigits(String s) {
    final b = StringBuffer();
    for (final r in s.runes) {
      final ch = String.fromCharCode(r);
      final d = int.tryParse(ch);
      b.write(d != null ? _bn[d] : ch);
    }
    return b.toString();
  }

  /// Bangladeshi digit grouping: 1,23,45,678
  static String groupBd(int n) {
    final s = n.abs().toString();
    String out;
    if (s.length <= 3) {
      out = s;
    } else {
      final last3 = s.substring(s.length - 3);
      var rest = s.substring(0, s.length - 3);
      final parts = <String>[];
      while (rest.length > 2) {
        parts.insert(0, rest.substring(rest.length - 2));
        rest = rest.substring(0, rest.length - 2);
      }
      if (rest.isNotEmpty) parts.insert(0, rest);
      out = '${parts.join(',')},$last3';
    }
    return n < 0 ? '-$out' : out;
  }

  /// 150050 -> "৳১,৫০০.৫০" (decimals shown only when non-zero).
  static String formatTaka(int poisha, {bool bengali = true}) {
    final neg = poisha < 0;
    final abs = poisha.abs();
    final taka = abs ~/ 100;
    final paisa = abs % 100;
    var text = groupBd(taka);
    if (paisa != 0) text += '.${paisa.toString().padLeft(2, '0')}';
    text = '৳$text';
    if (neg) text = '-$text';
    return bengali ? toBengaliDigits(text) : text;
  }
}
