import 'package:flutter/material.dart';

class AppColors {
  static const navy = Color(0xFF0B1F4B);
  static const emerald = Color(0xFF10B981);
  static const gold = Color(0xFFF5A524);
  static const softGray = Color(0xFFF4F6FA);
}

ThemeData buildTheme(Brightness b) {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.navy,
    primary: b == Brightness.light ? AppColors.navy : const Color(0xFF9DB4FF),
    secondary: AppColors.emerald,
    tertiary: AppColors.gold,
    brightness: b,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor:
        b == Brightness.light ? AppColors.softGray : const Color(0xFF0E1320),
    appBarTheme: const AppBarTheme(centerTitle: false),
  );
}
