import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'schema.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  /// Bumped after every committed financial write so screens can refresh.
  final ValueNotifier<int> dataVersion = ValueNotifier<int>(0);

  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    final path = p.join(dir, 'parvej_smart_assistant.db');
    return openDatabase(
      path,
      version: migrations.length,
      onConfigure: (d) async => d.execute('PRAGMA foreign_keys = ON'),
      onCreate: (d, version) async {
        for (var v = 0; v < version; v++) {
          for (final sql in migrations[v]) {
            await d.execute(sql);
          }
        }
      },
      onUpgrade: (d, oldV, newV) async {
        for (var v = oldV; v < newV; v++) {
          for (final sql in migrations[v]) {
            await d.execute(sql);
          }
        }
      },
    );
  }

  void notifyChanged() => dataVersion.value++;
}
