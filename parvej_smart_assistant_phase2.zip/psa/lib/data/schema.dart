/// Versioned migrations. Add a new string to [migrations] for every schema change;
/// never edit an old one. Database version = migrations.length.
const List<List<String>> migrations = [
  // ---- v1 ----
  [
    '''CREATE TABLE app_settings (
      key TEXT PRIMARY KEY, value TEXT NOT NULL)''',
    '''CREATE TABLE supplier_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)''',
    '''CREATE TABLE suppliers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      public_id TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      shop_name TEXT, contact_person TEXT, mobile TEXT, alt_mobile TEXT,
      email TEXT, address TEXT, market_name TEXT,
      category_id INTEGER REFERENCES supplier_categories(id),
      notes TEXT,
      is_temporary INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL)''',
    '''CREATE TABLE product_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)''',
    '''CREATE TABLE products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      category_id INTEGER REFERENCES product_categories(id),
      default_unit TEXT,
      last_unit_price INTEGER)''',
    '''CREATE TABLE payment_accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      type TEXT NOT NULL CHECK (type IN ('cash','bkash','nagad','bank','other')))''',
    // is_opening=1 rows carry a supplier's opening due; excluded from purchase totals.
    '''CREATE TABLE purchases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      public_id TEXT NOT NULL UNIQUE,
      supplier_id INTEGER REFERENCES suppliers(id),
      vendor_name TEXT,
      market_location TEXT,
      invoice_no TEXT,
      purchase_date TEXT NOT NULL,
      total_poisha INTEGER NOT NULL CHECK (total_poisha >= 0),
      funded_by TEXT NOT NULL DEFAULT 'personal' CHECK (funded_by IN ('personal','restaurant')),
      is_quick INTEGER NOT NULL DEFAULT 0,
      is_opening INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','reversed')),
      notes TEXT,
      created_at TEXT NOT NULL)''',
    '''CREATE TABLE purchase_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_id INTEGER NOT NULL REFERENCES purchases(id),
      product_name TEXT NOT NULL,
      category_id INTEGER REFERENCES product_categories(id),
      qty_milli INTEGER NOT NULL,
      unit TEXT,
      unit_price_poisha INTEGER NOT NULL,
      line_total_poisha INTEGER NOT NULL)''',
    '''CREATE TABLE invoice_images (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_id INTEGER NOT NULL REFERENCES purchases(id),
      relative_path TEXT NOT NULL,
      sha256 TEXT,
      created_at TEXT NOT NULL)''',
    '''CREATE TABLE supplier_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      public_id TEXT NOT NULL UNIQUE,
      supplier_id INTEGER REFERENCES suppliers(id),
      payment_date TEXT NOT NULL,
      amount_poisha INTEGER NOT NULL CHECK (amount_poisha > 0),
      account_id INTEGER NOT NULL REFERENCES payment_accounts(id),
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','reversed')),
      reversed_at TEXT, reversal_reason TEXT,
      created_at TEXT NOT NULL)''',
    '''CREATE TABLE payment_allocations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      payment_id INTEGER NOT NULL REFERENCES supplier_payments(id),
      purchase_id INTEGER NOT NULL REFERENCES purchases(id),
      amount_poisha INTEGER NOT NULL CHECK (amount_poisha > 0))''',
    '''CREATE TABLE supplier_advances (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      payment_id INTEGER NOT NULL REFERENCES supplier_payments(id),
      supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
      amount_poisha INTEGER NOT NULL CHECK (amount_poisha > 0))''',
    '''CREATE TABLE restaurant_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      txn_date TEXT NOT NULL,
      kind TEXT NOT NULL CHECK (kind IN ('payment','advance')),
      amount_poisha INTEGER NOT NULL CHECK (amount_poisha > 0),
      account_id INTEGER NOT NULL REFERENCES payment_accounts(id),
      reference TEXT, notes TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','reversed')),
      created_at TEXT NOT NULL)''',
    '''CREATE TABLE restaurant_payment_allocations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      restaurant_txn_id INTEGER NOT NULL REFERENCES restaurant_transactions(id),
      purchase_id INTEGER NOT NULL REFERENCES purchases(id),
      amount_poisha INTEGER NOT NULL CHECK (amount_poisha > 0))''',
    '''CREATE TABLE personal_funding_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      txn_date TEXT NOT NULL,
      kind TEXT NOT NULL CHECK (kind IN ('added','returned')),
      amount_poisha INTEGER NOT NULL CHECK (amount_poisha > 0),
      account_id INTEGER NOT NULL REFERENCES payment_accounts(id),
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','reversed')),
      created_at TEXT NOT NULL)''',
    // direction in/out. source_type says which record caused it.
    '''CREATE TABLE cash_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      txn_date TEXT NOT NULL,
      account_id INTEGER NOT NULL REFERENCES payment_accounts(id),
      direction TEXT NOT NULL CHECK (direction IN ('in','out')),
      amount_poisha INTEGER NOT NULL CHECK (amount_poisha > 0),
      source_type TEXT NOT NULL,
      source_id INTEGER,
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','reversed')),
      created_at TEXT NOT NULL)''',
    '''CREATE TABLE opening_balances (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id INTEGER NOT NULL REFERENCES payment_accounts(id),
      as_of_date TEXT NOT NULL,
      amount_poisha INTEGER NOT NULL)''',
    '''CREATE TABLE daily_closings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      closing_date TEXT NOT NULL UNIQUE,
      snapshot_json TEXT NOT NULL,
      is_stale INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL)''',
    '''CREATE TABLE financial_adjustments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      adj_date TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id INTEGER,
      amount_poisha INTEGER NOT NULL,
      reason TEXT NOT NULL,
      created_at TEXT NOT NULL)''',
    '''CREATE TABLE audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      at TEXT NOT NULL,
      action TEXT NOT NULL,
      entity TEXT NOT NULL,
      entity_id INTEGER,
      details TEXT)''',
    'CREATE INDEX idx_purchases_date ON purchases(purchase_date)',
    'CREATE INDEX idx_purchases_supplier ON purchases(supplier_id)',
    'CREATE INDEX idx_purchases_invoice ON purchases(invoice_no)',
    'CREATE INDEX idx_payments_date ON supplier_payments(payment_date)',
    'CREATE INDEX idx_payments_supplier ON supplier_payments(supplier_id)',
    'CREATE INDEX idx_alloc_purchase ON payment_allocations(purchase_id)',
    'CREATE INDEX idx_alloc_payment ON payment_allocations(payment_id)',
    'CREATE INDEX idx_items_purchase ON purchase_items(purchase_id)',
    'CREATE INDEX idx_cash_date ON cash_transactions(txn_date)',
    // ---- seed data ----
    "INSERT INTO payment_accounts(name,type) VALUES ('Cash','cash'),('bKash','bkash'),('Nagad','nagad'),('Bank Transfer','bank'),('Other','other')",
    "INSERT INTO supplier_categories(name) VALUES ('Fish'),('Seafood'),('Meat'),('Chicken'),('Vegetables'),('Groceries'),('Fruits'),('Spices'),('Rice'),('Oil'),('Packaging'),('Other')",
    "INSERT INTO product_categories(name) VALUES ('Street / Local Market Purchase')",
    "INSERT INTO app_settings(key,value) VALUES "
        "('owner_name','Md Parvej Musharap'),"
        "('restaurant_name','Sun Dancer Cafe & Restaurant'),"
        "('welcome_animation','1'),"
        "('language','bn'),"
        "('restaurant_model','B'),"
        "('default_funded_by','personal'),"
        "('default_payment_method','Cash')",
  ],
];
