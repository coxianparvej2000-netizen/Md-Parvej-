import 'dart:math';
import 'package:sqflite/sqflite.dart';
import '../domain/allocation.dart';
import 'app_database.dart';

class DuplicateEntryException implements Exception {
  final String message;
  DuplicateEntryException(this.message);
  @override
  String toString() => message;
}

class ValidationException implements Exception {
  final String message;
  ValidationException(this.message);
  @override
  String toString() => message;
}

class PurchaseItemInput {
  final String productName;
  final int qtyMilli;
  final String? unit;
  final int unitPricePoisha;
  final int lineTotalPoisha;
  PurchaseItemInput(this.productName, this.qtyMilli, this.unit,
      this.unitPricePoisha, this.lineTotalPoisha);
}

class DashboardSummary {
  final int todayPurchase;
  final int todaySupplierPayment;
  final int todayNewDue;
  final int previousDuePayment;
  final int paidAgainstToday;
  final int advanceToday;
  final int totalSupplierOutstanding;
  final int restaurantPaymentToday;
  final int restaurantOutstanding;
  final int availableCash;
  const DashboardSummary({
    required this.todayPurchase,
    required this.todaySupplierPayment,
    required this.todayNewDue,
    required this.previousDuePayment,
    required this.paidAgainstToday,
    required this.advanceToday,
    required this.totalSupplierOutstanding,
    required this.restaurantPaymentToday,
    required this.restaurantOutstanding,
    required this.availableCash,
  });
}

/// Remaining due per active purchase, derived only from transaction records.
const String _remainingSql = '''
SELECT u.id AS id, u.supplier_id AS supplier_id, u.purchase_date AS purchase_date,
       u.total_poisha AS total_poisha, u.is_opening AS is_opening, u.funded_by AS funded_by,
       u.total_poisha - COALESCE((
         SELECT SUM(a.amount_poisha) FROM payment_allocations a
         JOIN supplier_payments p ON p.id = a.payment_id
         WHERE a.purchase_id = u.id AND p.status = 'active'), 0) AS remaining
FROM purchases u WHERE u.status = 'active'
''';

class Repository {
  Repository(this._appDb);
  final AppDatabase _appDb;

  static final _rng = Random();
  static String newPublicId(String prefix) {
    final t = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
    final r = _rng.nextInt(1 << 32).toRadixString(36);
    return '$prefix-$t$r'.toUpperCase();
  }

  static String dateKey(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<int> _accountId(DatabaseExecutor e, String methodName) async {
    final r = await e.query('payment_accounts',
        columns: ['id'], where: 'name = ?', whereArgs: [methodName], limit: 1);
    if (r.isEmpty) throw ValidationException('Unknown payment method: $methodName');
    return r.first['id'] as int;
  }

  Future<void> _audit(DatabaseExecutor e, String action, String entity,
      int? id, String details) async {
    await e.insert('audit_logs', {
      'at': DateTime.now().toIso8601String(),
      'action': action,
      'entity': entity,
      'entity_id': id,
      'details': details,
    });
  }

  // ------------------------------------------------------------ suppliers
  Future<int> addSupplier({
    required String name,
    String? shopName,
    String? contactPerson,
    String? mobile,
    String? altMobile,
    String? email,
    String? address,
    String? marketName,
    int? categoryId,
    String? notes,
    int openingDuePoisha = 0,
    bool isTemporary = false,
  }) async {
    if (name.trim().isEmpty) throw ValidationException('Supplier name is required');
    final db = await _appDb.db;
    final id = await db.transaction<int>((txn) async {
      final now = DateTime.now();
      final sid = await txn.insert('suppliers', {
        'public_id': newPublicId('SUP'),
        'name': name.trim(),
        'shop_name': shopName,
        'contact_person': contactPerson,
        'mobile': mobile,
        'alt_mobile': altMobile,
        'email': email,
        'address': address,
        'market_name': marketName,
        'category_id': categoryId,
        'notes': notes,
        'is_temporary': isTemporary ? 1 : 0,
        'created_at': now.toIso8601String(),
      });
      if (openingDuePoisha > 0) {
        await txn.insert('purchases', {
          'public_id': newPublicId('OPN'),
          'supplier_id': sid,
          'invoice_no': 'OPENING',
          'purchase_date': dateKey(now),
          'total_poisha': openingDuePoisha,
          'is_opening': 1,
          'funded_by': 'personal',
          'created_at': now.toIso8601String(),
        });
      }
      await _audit(txn, 'create', 'supplier', sid, name.trim());
      return sid;
    });
    _appDb.notifyChanged();
    return id;
  }

  Future<List<Map<String, Object?>>> suppliers() async {
    final db = await _appDb.db;
    return db.rawQuery('''
      SELECT s.*, COALESCE(r.outstanding,0) AS outstanding
      FROM suppliers s
      LEFT JOIN (SELECT supplier_id, SUM(remaining) AS outstanding FROM ($_remainingSql) GROUP BY supplier_id) r
        ON r.supplier_id = s.id
      ORDER BY s.name COLLATE NOCASE''');
  }

  // ------------------------------------------------------------ purchases
  /// Creates a purchase (with items) and, if [paidNowPoisha] > 0, an immediate
  /// payment + allocation + cash-out, all in ONE atomic transaction.
  Future<int> createPurchase({
    required String purchaseDate,
    required List<PurchaseItemInput> items,
    int? supplierId,
    String? vendorName,
    String? marketLocation,
    String? invoiceNo,
    int paidNowPoisha = 0,
    String paymentMethod = 'Cash',
    String fundedBy = 'personal',
    bool isQuick = false,
    String? notes,
  }) async {
    if (items.isEmpty) throw ValidationException('Add at least one product');
    final total = items.fold<int>(0, (s, i) => s + i.lineTotalPoisha);
    if (paidNowPoisha < 0) throw ValidationException('Invalid payment');
    if (paidNowPoisha > total) {
      throw ValidationException('Paid amount is more than the invoice total');
    }
    final due = total - paidNowPoisha;
    if (supplierId == null && due > 0 && (vendorName == null || vendorName.trim().isEmpty)) {
      throw ValidationException('A vendor name is required when money is unpaid');
    }
    final inv = invoiceNo?.trim();
    final db = await _appDb.db;
    final id = await db.transaction<int>((txn) async {
      if (inv != null && inv.isNotEmpty) {
        final dup = await txn.rawQuery(
          'SELECT id FROM purchases WHERE status = \'active\' AND invoice_no = ? '
          'AND purchase_date = ? AND COALESCE(supplier_id,-1) = ?',
          [inv, purchaseDate, supplierId ?? -1]);
        if (dup.isNotEmpty) {
          throw DuplicateEntryException('Invoice $inv already exists for this supplier and date');
        }
      }
      final now = DateTime.now().toIso8601String();
      final pid = await txn.insert('purchases', {
        'public_id': newPublicId('PUR'),
        'supplier_id': supplierId,
        'vendor_name': vendorName?.trim(),
        'market_location': marketLocation,
        'invoice_no': (inv == null || inv.isEmpty) ? null : inv,
        'purchase_date': purchaseDate,
        'total_poisha': total,
        'funded_by': fundedBy,
        'is_quick': isQuick ? 1 : 0,
        'notes': notes,
        'created_at': now,
      });
      for (final it in items) {
        await txn.insert('purchase_items', {
          'purchase_id': pid,
          'product_name': it.productName.trim(),
          'qty_milli': it.qtyMilli,
          'unit': it.unit,
          'unit_price_poisha': it.unitPricePoisha,
          'line_total_poisha': it.lineTotalPoisha,
        });
        await txn.rawInsert(
            'INSERT INTO products(name, default_unit, last_unit_price) VALUES (?,?,?) '
            'ON CONFLICT(name) DO UPDATE SET last_unit_price = excluded.last_unit_price, '
            'default_unit = COALESCE(excluded.default_unit, default_unit)',
            [it.productName.trim(), it.unit, it.unitPricePoisha]);
      }
      if (paidNowPoisha > 0) {
        final accId = await _accountId(txn, paymentMethod);
        final payId = await txn.insert('supplier_payments', {
          'public_id': newPublicId('PAY'),
          'supplier_id': supplierId,
          'payment_date': purchaseDate,
          'amount_poisha': paidNowPoisha,
          'account_id': accId,
          'notes': 'Paid at purchase',
          'created_at': now,
        });
        await txn.insert('payment_allocations',
            {'payment_id': payId, 'purchase_id': pid, 'amount_poisha': paidNowPoisha});
        await txn.insert('cash_transactions', {
          'txn_date': purchaseDate,
          'account_id': accId,
          'direction': 'out',
          'amount_poisha': paidNowPoisha,
          'source_type': 'supplier_payment',
          'source_id': payId,
          'created_at': now,
        });
      }
      await _audit(txn, 'create', 'purchase', pid, 'total=$total paid=$paidNowPoisha');
      return pid;
    });
    _appDb.notifyChanged();
    return id;
  }

  // ------------------------------------------------------- previous dues
  Future<List<DueInvoice>> dueInvoices(int supplierId) async {
    final db = await _appDb.db;
    final rows = await db.rawQuery(
        'SELECT id, purchase_date, remaining FROM ($_remainingSql) '
        'WHERE supplier_id = ? AND remaining > 0 ORDER BY purchase_date, id',
        [supplierId]);
    return rows
        .map((r) => DueInvoice(r['id'] as int, r['purchase_date'] as String, r['remaining'] as int))
        .toList();
  }

  /// Records a payment. [preview] must come from AllocationLogic and must have
  /// been shown to the user. If preview.excess > 0 it is only stored when
  /// [acceptExcessAsAdvance] is true; otherwise the call is rejected.
  Future<int> paySupplier({
    required int supplierId,
    required String paymentDate,
    required int amountPoisha,
    required String paymentMethod,
    required AllocationPreview preview,
    bool acceptExcessAsAdvance = false,
    String? notes,
  }) async {
    if (amountPoisha <= 0) throw ValidationException('Payment must be greater than zero');
    if (preview.allocated + preview.excess != amountPoisha) {
      throw ValidationException('Allocation does not match payment amount');
    }
    if (preview.excess > 0 && !acceptExcessAsAdvance) {
      throw ValidationException('Payment exceeds outstanding. Confirm to record excess as advance.');
    }
    final db = await _appDb.db;
    final id = await db.transaction<int>((txn) async {
      // Re-validate against live balances inside the transaction.
      for (final a in preview.allocations) {
        final r = await txn.rawQuery(
            'SELECT remaining FROM ($_remainingSql) WHERE id = ? AND supplier_id = ?',
            [a.purchaseId, supplierId]);
        if (r.isEmpty || (r.first['remaining'] as int) < a.amount) {
          throw ValidationException('Invoice ${a.purchaseId} balance changed; reopen the payment screen');
        }
      }
      final now = DateTime.now().toIso8601String();
      final accId = await _accountId(txn, paymentMethod);
      final payId = await txn.insert('supplier_payments', {
        'public_id': newPublicId('PAY'),
        'supplier_id': supplierId,
        'payment_date': paymentDate,
        'amount_poisha': amountPoisha,
        'account_id': accId,
        'notes': notes,
        'created_at': now,
      });
      for (final a in preview.allocations) {
        await txn.insert('payment_allocations',
            {'payment_id': payId, 'purchase_id': a.purchaseId, 'amount_poisha': a.amount});
      }
      if (preview.excess > 0) {
        await txn.insert('supplier_advances',
            {'payment_id': payId, 'supplier_id': supplierId, 'amount_poisha': preview.excess});
      }
      await txn.insert('cash_transactions', {
        'txn_date': paymentDate,
        'account_id': accId,
        'direction': 'out',
        'amount_poisha': amountPoisha,
        'source_type': 'supplier_payment',
        'source_id': payId,
        'created_at': now,
      });
      await _audit(txn, 'create', 'supplier_payment', payId,
          'amount=$amountPoisha excess=${preview.excess}');
      return payId;
    });
    _appDb.notifyChanged();
    return id;
  }

  /// Reverses a payment (never deletes it). Allocations and cash-out stop
  /// counting; the invoice's remaining due is restored automatically.
  Future<void> reversePayment(int paymentId, String reason) async {
    if (reason.trim().isEmpty) throw ValidationException('A reason is required');
    final db = await _appDb.db;
    await db.transaction((txn) async {
      final n = await txn.update(
          'supplier_payments',
          {'status': 'reversed', 'reversed_at': DateTime.now().toIso8601String(), 'reversal_reason': reason},
          where: "id = ? AND status = 'active'",
          whereArgs: [paymentId]);
      if (n == 0) throw ValidationException('Payment not found or already reversed');
      await txn.update('cash_transactions', {'status': 'reversed'},
          where: "source_type = 'supplier_payment' AND source_id = ?", whereArgs: [paymentId]);
      await txn.delete('supplier_advances', where: 'payment_id = ?', whereArgs: [paymentId]);
      await _audit(txn, 'reverse', 'supplier_payment', paymentId, reason);
      // Any stored daily closing from this payment's date onward is now stale.
      final p = await txn.query('supplier_payments',
          columns: ['payment_date'], where: 'id = ?', whereArgs: [paymentId]);
      await txn.update('daily_closings', {'is_stale': 1},
          where: 'closing_date >= ?', whereArgs: [p.first['payment_date']]);
    });
    _appDb.notifyChanged();
  }

  // ------------------------------------------------ restaurant & personal
  Future<int> addRestaurantPayment({
    required String date,
    required int amountPoisha,
    required String method,
    String? reference,
    String? notes,
  }) async {
    if (amountPoisha <= 0) throw ValidationException('Amount must be greater than zero');
    final db = await _appDb.db;
    final id = await db.transaction<int>((txn) async {
      final now = DateTime.now().toIso8601String();
      final acc = await _accountId(txn, method);
      final tid = await txn.insert('restaurant_transactions', {
        'txn_date': date,
        'kind': 'payment',
        'amount_poisha': amountPoisha,
        'account_id': acc,
        'reference': reference,
        'notes': notes,
        'created_at': now,
      });
      await txn.insert('cash_transactions', {
        'txn_date': date,
        'account_id': acc,
        'direction': 'in',
        'amount_poisha': amountPoisha,
        'source_type': 'restaurant_payment',
        'source_id': tid,
        'created_at': now,
      });
      await _audit(txn, 'create', 'restaurant_transaction', tid, 'amount=$amountPoisha');
      return tid;
    });
    _appDb.notifyChanged();
    return id;
  }

  Future<int> addPersonalFunding({
    required String date,
    required bool added,
    required int amountPoisha,
    required String method,
    String? notes,
  }) async {
    if (amountPoisha <= 0) throw ValidationException('Amount must be greater than zero');
    final db = await _appDb.db;
    final id = await db.transaction<int>((txn) async {
      final now = DateTime.now().toIso8601String();
      final acc = await _accountId(txn, method);
      final tid = await txn.insert('personal_funding_transactions', {
        'txn_date': date,
        'kind': added ? 'added' : 'returned',
        'amount_poisha': amountPoisha,
        'account_id': acc,
        'notes': notes,
        'created_at': now,
      });
      await txn.insert('cash_transactions', {
        'txn_date': date,
        'account_id': acc,
        'direction': added ? 'in' : 'out',
        'amount_poisha': amountPoisha,
        'source_type': 'personal_funding',
        'source_id': tid,
        'created_at': now,
      });
      await _audit(txn, 'create', 'personal_funding', tid, 'amount=$amountPoisha');
      return tid;
    });
    _appDb.notifyChanged();
    return id;
  }

  // ------------------------------------------------------------- settings
  Future<String?> setting(String key) async {
    final db = await _appDb.db;
    final r = await db.query('app_settings', where: 'key = ?', whereArgs: [key]);
    return r.isEmpty ? null : r.first['value'] as String;
  }

  Future<void> putSetting(String key, String value) async {
    final db = await _appDb.db;
    await db.insert('app_settings', {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ------------------------------------------------------------ dashboard
  Future<int> _scalar(DatabaseExecutor e, String sql, [List<Object?> args = const []]) async {
    final r = await e.rawQuery(sql, args);
    final v = r.first.values.first;
    return (v as num?)?.toInt() ?? 0;
  }

  Future<DashboardSummary> dashboard(String today) async {
    final db = await _appDb.db;
    final todayPurchase = await _scalar(db,
        "SELECT SUM(total_poisha) FROM purchases WHERE status='active' AND is_opening=0 AND purchase_date=?",
        [today]);
    final todayPayment = await _scalar(db,
        "SELECT SUM(amount_poisha) FROM supplier_payments WHERE status='active' AND payment_date=?",
        [today]);
    final paidAgainstToday = await _scalar(db, '''
        SELECT SUM(a.amount_poisha) FROM payment_allocations a
        JOIN supplier_payments p ON p.id=a.payment_id
        JOIN purchases u ON u.id=a.purchase_id
        WHERE p.status='active' AND u.status='active' AND p.payment_date=? AND u.purchase_date=?''',
        [today, today]);
    final previousDue = await _scalar(db, '''
        SELECT SUM(a.amount_poisha) FROM payment_allocations a
        JOIN supplier_payments p ON p.id=a.payment_id
        JOIN purchases u ON u.id=a.purchase_id
        WHERE p.status='active' AND u.status='active' AND p.payment_date=? AND u.purchase_date<?''',
        [today, today]);
    final advanceToday = await _scalar(db, '''
        SELECT SUM(v.amount_poisha) FROM supplier_advances v
        JOIN supplier_payments p ON p.id=v.payment_id
        WHERE p.status='active' AND p.payment_date=?''', [today]);
    // New due = today's purchases minus everything paid against them so far.
    final paidToTodaysPurchases = await _scalar(db, '''
        SELECT SUM(a.amount_poisha) FROM payment_allocations a
        JOIN supplier_payments p ON p.id=a.payment_id
        JOIN purchases u ON u.id=a.purchase_id
        WHERE p.status='active' AND u.status='active' AND u.is_opening=0 AND u.purchase_date=?''',
        [today]);
    final totalOutstanding = await _scalar(db, 'SELECT SUM(remaining) FROM ($_remainingSql)');

    final restReceivedToday = await _scalar(db,
        "SELECT SUM(amount_poisha) FROM restaurant_transactions WHERE status='active' AND kind='payment' AND txn_date=?",
        [today]);
    final restReceivedAll = await _scalar(db,
        "SELECT SUM(amount_poisha) FROM restaurant_transactions WHERE status='active' AND kind='payment'");
    final model = (await setting('restaurant_model')) ?? 'B';
    int restOutstanding;
    if (model == 'A') {
      // Restaurant owes for every purchase, regardless of how it was paid.
      final all = await _scalar(db,
          "SELECT SUM(total_poisha) FROM purchases WHERE status='active' AND is_opening=0");
      restOutstanding = all - restReceivedAll;
    } else {
      // Model B (default): only what I actually paid from my own money.
      final paidPersonal = await _scalar(db,
          "SELECT SUM(total_poisha - remaining) FROM ($_remainingSql) WHERE is_opening=0 AND funded_by='personal'");
      restOutstanding = paidPersonal - restReceivedAll;
    }

    // Available cash: cash-type accounts only. Unpaid invoices never appear here.
    final opening = await _scalar(db,
        "SELECT SUM(o.amount_poisha) FROM opening_balances o JOIN payment_accounts a ON a.id=o.account_id WHERE a.type='cash'");
    final cashFlow = await _scalar(db, '''
        SELECT SUM(CASE c.direction WHEN 'in' THEN c.amount_poisha ELSE -c.amount_poisha END)
        FROM cash_transactions c JOIN payment_accounts a ON a.id=c.account_id
        WHERE c.status='active' AND a.type='cash' ''');

    return DashboardSummary(
      todayPurchase: todayPurchase,
      todaySupplierPayment: todayPayment,
      todayNewDue: todayPurchase - paidToTodaysPurchases,
      previousDuePayment: previousDue,
      paidAgainstToday: paidAgainstToday,
      advanceToday: advanceToday,
      totalSupplierOutstanding: totalOutstanding,
      restaurantPaymentToday: restReceivedToday,
      restaurantOutstanding: restOutstanding,
      availableCash: opening + cashFlow,
    );
  }

  /// Outstanding grouped by ORIGINAL purchase date, with payment breakdown.
  Future<List<Map<String, Object?>>> outstandingByDate() async {
    final db = await _appDb.db;
    return db.rawQuery('''
      SELECT purchase_date,
             SUM(total_poisha) AS original,
             SUM(remaining) AS remaining,
             SUM(total_poisha - remaining) AS paid_total
      FROM ($_remainingSql)
      WHERE remaining > 0
      GROUP BY purchase_date ORDER BY purchase_date''');
  }

  Future<List<Map<String, Object?>>> outstandingInvoicesOn(String date) async {
    final db = await _appDb.db;
    return db.rawQuery('''
      SELECT r.id, r.total_poisha, r.remaining, u.invoice_no,
             COALESCE(s.name, u.vendor_name, '—') AS supplier_name
      FROM ($_remainingSql) r
      JOIN purchases u ON u.id = r.id
      LEFT JOIN suppliers s ON s.id = u.supplier_id
      WHERE r.purchase_date = ? AND r.remaining > 0
      ORDER BY supplier_name''', [date]);
  }
}
