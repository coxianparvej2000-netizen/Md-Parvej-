import 'dart:async';
import 'package:flutter/material.dart';
import '../core/strings.dart';
import '../core/theme.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key, required this.ownerName, required this.onDone});
  final String ownerName;
  final VoidCallback onDone;
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _glow =
      AnimationController(vsync: this, duration: const Duration(seconds: 2))
        ..repeat(reverse: true);
  late final List<String> _lines = [
    'হ্যালো, ${widget.ownerName}!',
    'আমি আপনার ভার্চুয়াল অ্যাসিস্ট্যান্ট।',
    'PARVEJ SMART ASSISTANT-এ স্বাগতম।',
    'চলুন, আপনার ক্রয়ের হিসাব আরও স্মার্ট করি।',
  ];
  int _index = 0;
  bool _finished = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    // 4 lines x 1.1s = ~4.4s total.
    _timer = Timer.periodic(const Duration(milliseconds: 1100), (t) {
      if (_index >= _lines.length - 1) {
        t.cancel();
        Timer(const Duration(milliseconds: 600), _finish);
      } else {
        setState(() => _index++);
      }
    });
  }

  void _finish() {
    if (_finished || !mounted) return;
    _finished = true;
    widget.onDone();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _glow.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.navy, Color(0xFF123A6B), Color(0xFF0B6B57)],
          ),
        ),
        child: SafeArea(
          child: Stack(children: [
            Align(
              alignment: Alignment.topRight,
              child: TextButton(
                onPressed: () {
                  _timer?.cancel();
                  _finish();
                },
                child: const Text(S.skip, style: TextStyle(color: Colors.white70)),
              ),
            ),
            Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                AnimatedBuilder(
                  animation: _glow,
                  builder: (_, __) => Container(
                    width: 112,
                    height: 112,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                          colors: [AppColors.emerald, AppColors.gold]),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.gold.withOpacity(0.25 + 0.35 * _glow.value),
                          blurRadius: 24 + 28 * _glow.value,
                          spreadRadius: 2 + 6 * _glow.value,
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: const Text('P',
                        style: TextStyle(
                            fontSize: 64,
                            fontWeight: FontWeight.w900,
                            color: Colors.white)),
                  ),
                ),
                const SizedBox(height: 36),
                SizedBox(
                  height: 90,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 500),
                      child: Text(
                        _lines[_index],
                        key: ValueKey(_index),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w600,
                            height: 1.4),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                const SizedBox(
                  width: 120,
                  child: LinearProgressIndicator(
                    color: AppColors.gold,
                    backgroundColor: Colors.white24,
                    minHeight: 4,
                  ),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
