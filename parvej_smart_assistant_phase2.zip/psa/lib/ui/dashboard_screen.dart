import 'package:flutter/material.dart';
import '../core/money.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../data/app_database.dart';
import '../data/repository.dart';
import 'outstanding_history_screen.dart';
import 'coming_soon.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, required this.repo, required this.ownerName});
  final Repository repo;
  final String ownerName;
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<DashboardSummary> _future;

  @override
  void initState() {
    super.initState();
    _reload();
    AppDatabase.instance.dataVersion.addListener(_reload);
  }

  void _reload() {
    if (!mounted) return;
    setState(() {
      _future = widget.repo.dashboard(Repository.dateKey(DateTime.now()));
    });
  }

  @override
  void dispose() {
    AppDatabase.instance.dataVersion.removeListener(_reload);
    super.dispose();
  }

  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 12) return S.goodMorning;
    if (h < 17) return S.goodAfternoon;
    return S.goodEvening;
  }

  static const _weekdays = ['সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার', 'রবিবার'];
  static const _months = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  String get _dateText {
    final d = DateTime.now();
    return Money.toBengaliDigits(
        '${_weekdays[d.weekday - 1]}, ${d.day} ${_months[d.month - 1]} ${d.year}');
  }

  void _open(Widget page) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<DashboardSummary>(
      future: _future,
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(child: Text('ত্রুটি: ${snap.error}'));
        }
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final s = snap.data!;
        final cards = <_CardData>[
          _CardData(S.todayPurchase, s.todayPurchase, Icons.shopping_basket_rounded,
              AppColors.navy, () => _open(const ComingSoon(title: S.todayPurchase))),
          _CardData(S.todaySupplierPayment, s.todaySupplierPayment, Icons.payments_rounded,
              AppColors.emerald, () => _open(const ComingSoon(title: S.todaySupplierPayment))),
          _CardData(S.todayNewDue, s.todayNewDue, Icons.hourglass_bottom_rounded,
              AppColors.gold, () => _open(const OutstandingHistoryScreen())),
          _CardData(S.previousDuePayment, s.previousDuePayment, Icons.history_rounded,
              const Color(0xFF6C5CE7), () => _open(const ComingSoon(title: S.previousDuePayment))),
          _CardData(S.totalOutstanding, s.totalSupplierOutstanding, Icons.warning_amber_rounded,
              const Color(0xFFE5484D), () => _open(const OutstandingHistoryScreen())),
          _CardData(S.restaurantReceived, s.restaurantPaymentToday, Icons.storefront_rounded,
              const Color(0xFF0EA5E9), () => _open(const ComingSoon(title: S.restaurantReceived))),
          _CardData(S.restaurantOutstanding, s.restaurantOutstanding, Icons.account_balance_wallet_rounded,
              const Color(0xFFEA580C), () => _open(const ComingSoon(title: S.restaurantOutstanding))),
          _CardData(S.availableCash, s.availableCash, Icons.savings_rounded,
              const Color(0xFF059669), () => _open(const ComingSoon(title: S.availableCash))),
        ];
        return RefreshIndicator(
          onRefresh: () async => _reload(),
          child: LayoutBuilder(builder: (context, c) {
            final cols = c.maxWidth >= 840 ? 4 : (c.maxWidth >= 560 ? 3 : 2);
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text('$_greeting, ${widget.ownerName}',
                    style: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(_dateText, style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 16),
                GridView.count(
                  crossAxisCount: cols,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: cols == 2 ? 1.15 : 1.35,
                  children: cards.map((d) => _SummaryCard(data: d)).toList(),
                ),
              ],
            );
          }),
        );
      },
    );
  }
}

class _CardData {
  final String label;
  final int poisha;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  _CardData(this.label, this.poisha, this.icon, this.color, this.onTap);
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.data});
  final _CardData data;
  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: data.onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: data.color.withOpacity(0.14),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(data.icon, color: data.color, size: 22),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(Money.formatTaka(data.poisha),
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                ),
                const SizedBox(height: 2),
                Text(data.label,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
