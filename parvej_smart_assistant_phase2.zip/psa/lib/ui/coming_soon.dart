import 'package:flutter/material.dart';

/// Honest marker for screens scheduled for a later phase.
class ComingSoon extends StatelessWidget {
  const ComingSoon({super.key, required this.title});
  final String title;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Text('এই পাতাটি পরবর্তী ধাপে (Phase 3/4) যুক্ত হবে।',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium),
          ),
        ),
      );
}
