import 'package:flutter/material.dart';
import '../core/money.dart';
import '../core/strings.dart';
import '../data/app_database.dart';
import '../data/repository.dart';

class OutstandingHistoryScreen extends StatefulWidget {
  const OutstandingHistoryScreen({super.key});
  @override
  State<OutstandingHistoryScreen> createState() => _OutstandingHistoryScreenState();
}

class _OutstandingHistoryScreenState extends State<OutstandingHistoryScreen> {
  final repo = Repository(AppDatabase.instance);
  late Future<List<Map<String, Object?>>> _future = repo.outstandingByDate();

  @override
  void initState() {
    super.initState();
    AppDatabase.instance.dataVersion.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() => _future = repo.outstandingByDate());
  }

  @override
  void dispose() {
    AppDatabase.instance.dataVersion.removeListener(_refresh);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text(S.outstandingHistory)),
      body: FutureBuilder<List<Map<String, Object?>>>(
        future: _future,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final rows = snap.data!;
          if (rows.isEmpty) {
            return const Center(child: Text('কোনো বকেয়া নেই 🎉'));
          }
          final total = rows.fold<int>(0, (s, r) => s + (r['remaining'] as int));
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Card(
                child: ListTile(
                  title: const Text(S.totalOutstanding),
                  trailing: Text(Money.formatTaka(total),
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                ),
              ),
              for (final r in rows)
                Card(
                  child: ListTile(
                    title: Text(Money.toBengaliDigits(r['purchase_date'] as String)),
                    subtitle: Text(
                        'মূল ক্রয়: ${Money.formatTaka(r['original'] as int)}  •  পরিশোধিত: ${Money.formatTaka(r['paid_total'] as int)}'),
                    trailing: Text(Money.formatTaka(r['remaining'] as int),
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => _InvoicesOnDate(date: r['purchase_date'] as String))),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _InvoicesOnDate extends StatelessWidget {
  const _InvoicesOnDate({required this.date});
  final String date;
  @override
  Widget build(BuildContext context) {
    final repo = Repository(AppDatabase.instance);
    return Scaffold(
      appBar: AppBar(title: Text(Money.toBengaliDigits(date))),
      body: FutureBuilder<List<Map<String, Object?>>>(
        future: repo.outstandingInvoicesOn(date),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          return ListView(
            children: [
              for (final r in snap.data!)
                ListTile(
                  title: Text(r['supplier_name'] as String),
                  subtitle: Text(
                      'চালান: ${r['invoice_no'] ?? '—'}  •  মোট: ${Money.formatTaka(r['total_poisha'] as int)}'),
                  trailing: Text(Money.formatTaka(r['remaining'] as int),
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
            ],
          );
        },
      ),
    );
  }
}
