import 'package:flutter/material.dart';
import '../core/strings.dart';
import '../data/repository.dart';
import 'coming_soon.dart';
import 'dashboard_screen.dart';
import 'outstanding_history_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.repo, required this.ownerName});
  final Repository repo;
  final String ownerName;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  static const _phoneTabs = [S.home, S.purchases, S.suppliers, S.dues, S.more];
  static const _phoneIcons = [
    Icons.dashboard_rounded,
    Icons.receipt_long_rounded,
    Icons.groups_rounded,
    Icons.account_balance_rounded,
    Icons.more_horiz_rounded,
  ];

  Widget _page(int i) {
    switch (i) {
      case 0:
        return DashboardScreen(repo: widget.repo, ownerName: widget.ownerName);
      case 3:
        return const OutstandingHistoryScreen();
      default:
        return ComingSoon(title: _phoneTabs[i]);
    }
  }

  void _newPurchase() => Navigator.of(context)
      .push(MaterialPageRoute(builder: (_) => const ComingSoon(title: S.newPurchase)));

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width >= 840;
    final fab = FloatingActionButton.extended(
      onPressed: _newPurchase,
      icon: const Icon(Icons.add),
      label: const Text(S.newPurchase),
    );
    if (wide) {
      return Scaffold(
        body: Row(children: [
          NavigationRail(
            extended: true,
            selectedIndex: _index,
            onDestinationSelected: (i) => setState(() => _index = i),
            leading: const Padding(
              padding: EdgeInsets.all(16),
              child: Text('PARVEJ\nSMART ASSISTANT',
                  style: TextStyle(fontWeight: FontWeight.w900, height: 1.2)),
            ),
            destinations: [
              for (var i = 0; i < _phoneTabs.length; i++)
                NavigationRailDestination(
                    icon: Icon(_phoneIcons[i]), label: Text(_phoneTabs[i])),
            ],
          ),
          const VerticalDivider(width: 1),
          Expanded(child: _page(_index)),
        ]),
        floatingActionButton: fab,
      );
    }
    return Scaffold(
      appBar: _index == 0 ? AppBar(title: const Text(S.appName)) : null,
      body: _page(_index),
      floatingActionButton: fab,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          for (var i = 0; i < _phoneTabs.length; i++)
            NavigationDestination(icon: Icon(_phoneIcons[i]), label: _phoneTabs[i]),
        ],
      ),
    );
  }
}
