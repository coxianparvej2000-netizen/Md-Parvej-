import 'package:flutter_test/flutter_test.dart';
import 'package:parvej_smart_assistant/core/money.dart';
import 'package:parvej_smart_assistant/domain/allocation.dart';

void main() {
  group('Money', () {
    test('parses Taka to poisha, English and Bengali digits', () {
      expect(Money.parseTaka('1500.50'), 150050);
      expect(Money.parseTaka('১৫০০.৫'), 150050);
      expect(Money.parseTaka('1,200'), 120000);
      expect(Money.parseTaka(''), 0);
    });
    test('rejects invalid input', () {
      expect(() => Money.parseTaka('12a'), throwsFormatException);
      expect(() => Money.parseTaka('-5'), throwsFormatException);
    });
    test('quantity and line total rounding (half up)', () {
      expect(Money.parseQtyMilli('2.5'), 2500);
      expect(Money.lineTotal(2500, 48000), 120000); // 2.5kg x 480 = 1200
      expect(Money.lineTotal(333, 10000), 3330); // 0.333 x 100 = 33.30
      expect(Money.lineTotal(1, 500), 1); // 0.5 poisha rounds up
    });
    test('Bangladeshi grouping', () {
      expect(Money.groupBd(1234567), '12,34,567');
      expect(Money.groupBd(999), '999');
      expect(Money.formatTaka(150050, bengali: false), '৳1,500.50');
    });
  });

  group('Allocation', () {
    final invoices = [
      DueInvoice(2, '2026-10-21', 200000),
      DueInvoice(1, '2026-10-20', 300000),
      DueInvoice(3, '2026-10-22', 100000),
    ];
    test('oldest first fills Oct 20 before later dates', () {
      final p = AllocationLogic.oldestFirst(invoices, 150000);
      expect(p.allocations, [Allocation(1, 150000)]);
      expect(p.excess, 0);
    });
    test('spills over to the next invoice', () {
      final p = AllocationLogic.oldestFirst(invoices, 400000);
      expect(p.allocations, [Allocation(1, 300000), Allocation(2, 100000)]);
    });
    test('excess becomes advance candidate, never negative balance', () {
      final p = AllocationLogic.oldestFirst(invoices, 700000);
      expect(p.allocated, 600000);
      expect(p.excess, 100000);
    });
    test('manual allocation cannot exceed an invoice balance', () {
      expect(() => AllocationLogic.manual(invoices, {1: 300001}, 300001),
          throwsA(isA<AllocationError>()));
    });
    test('manual allocation cannot exceed payment amount', () {
      expect(() => AllocationLogic.manual(invoices, {1: 200000, 2: 200000}, 300000),
          throwsA(isA<AllocationError>()));
    });
  });
}
