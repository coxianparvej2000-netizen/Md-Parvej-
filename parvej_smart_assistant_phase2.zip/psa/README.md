# PARVEJ SMART ASSISTANT (Phase 2)

Offline Flutter + SQLite (sqflite). NOT yet compiled or run by the author's tooling.

## Build (on your PC with Flutter 3.19+ and Android SDK)
    flutter create --platforms=android --org com.parvej --project-name parvej_smart_assistant .
    flutter pub get
    flutter test
    flutter build apk --release
APK: build/app/outputs/flutter-apk/app-release.apk

(`flutter create .` only adds the missing android/ folder; it keeps lib/ and pubspec.yaml.)

## Build from an Android tablet (no PC)
Use GitHub Actions: upload this project to a private GitHub repo, open Actions > "Build APK" > Run workflow,
then download the APK artifact when it finishes (see .github/workflows/build.yml).
